*PADS-LIBRARY-PART-TYPES-V9*

ULN2803ADWR SOIC127P1030X265-18N I TRX 7 1 0 0 0
TIMESTAMP 2026.11.10.12.18.22
"Mouser Part Number" 595-ULN2803ADWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ULN2803ADWR?qs=zqbRmZ%252BfZD8M77SqrzUfYg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ULN2803ADWR
"Description" Darlington Transistor Array
"Datasheet Link" http://www.ti.com/lit/gpn/uln2803a
"Geometry.Height" 2.65mm
GATE 1 18 0
ULN2803ADWR
1 0 U 1B
2 0 U 2B
3 0 U 3B
4 0 U 4B
5 0 U 5B
6 0 U 6B
7 0 U 7B
8 0 U 8B
9 0 U GND
18 0 U 1C
17 0 U 2C
16 0 U 3C
15 0 U 4C
14 0 U 5C
13 0 U 6C
12 0 U 7C
11 0 U 8C
10 0 U COM

*END*
*REMARK* SamacSys ECAD Model
234188/2152596/2.50/18/3/Transistor
