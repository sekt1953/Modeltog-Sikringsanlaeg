*PADS-LIBRARY-PART-TYPES-V9*

ILQ621GB-X017T SOP254P1030X470-16N I ANA 7 1 0 0 0
TIMESTAMP 2026.11.23.19.59.03
"Mouser Part Number" 782-ILQ621GB-X017T
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Semiconductors/ILQ621GB-X017T?qs=%2Fjqivxn91cep6dKZN8S1JQ%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" ILQ621GB-X017T
"Description" Transistor Output Optocouplers Phototransistor Out Quad CTR > 100%
"Datasheet Link" https://www.vishay.com/docs/83654/ild621.pdf
"Geometry.Height" 4.7mm
GATE 1 16 0
ILQ621GB-X017T
1 0 U A_1
2 0 U C_1
3 0 U A_2
4 0 U C_2
5 0 U A_3
6 0 U C_3
7 0 U A_4
8 0 U C_4
16 0 U C_8
15 0 U E_4
14 0 U C_7
13 0 U E_3
12 0 U C_6
11 0 U E_2
10 0 U C_5
9 0 U E_1

*END*
*REMARK* SamacSys ECAD Model
1376942/2152596/2.50/16/0/Phototransistor
