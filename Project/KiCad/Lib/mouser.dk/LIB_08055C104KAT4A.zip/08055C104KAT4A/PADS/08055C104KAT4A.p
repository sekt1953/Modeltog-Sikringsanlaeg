*PADS-LIBRARY-PART-TYPES-V9*

08055C104KAT4A CAPC2012X94N I CAP 7 1 0 0 0
TIMESTAMP 2026.11.11.12.45.08
"Mouser Part Number" 581-08055C104KAT4A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KYOCERA-AVX/08055C104KAT4A?qs=2ujN4bDBNE8aFT7CFyBStg%3D%3D
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" 08055C104KAT4A
"Description" AVX, 0805 (2012M) 100nF MLCC 50V dc +/-10% , SMD 08055C104KAT4A
"Datasheet Link" https://datasheets.avx.com/X7RDielectric.pdf
"Geometry.Height" 0.94mm
GATE 1 2 0
08055C104KAT4A
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
345443/2152596/2.50/2/3/Capacitor
