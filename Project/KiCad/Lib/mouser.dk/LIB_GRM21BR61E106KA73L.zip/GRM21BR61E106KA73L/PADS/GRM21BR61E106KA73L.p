*PADS-LIBRARY-PART-TYPES-V9*

GRM21BR61E106KA73L CAPC2012X145N I CAP 7 1 0 0 0
TIMESTAMP 2026.11.11.13.04.12
"Mouser Part Number" 81-GRM21BR61E106KA3L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/GRM21BR61E106KA73L?qs=Uw8ySfEHS7LOsCQEzvRcNg%3D%3D
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" GRM21BR61E106KA73L
"Description" Ceramic Capacitors MLCC 0805 10uF 25V Murata 0805 GRM 10uF Ceramic Multilayer Capacitor, 25 V dc, +85C, X5R Dielectric, +/-10% SMD
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM21BR61E106KA73-01A.pdf
"Geometry.Height" 1.45mm
GATE 1 2 0
GRM21BR61E106KA73L
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
234594/2152596/2.50/2/2/Capacitor
