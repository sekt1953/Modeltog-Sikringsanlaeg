*PADS-LIBRARY-PART-TYPES-V9*

BC857 SOT95P240X115-3N I ANA 7 1 0 0 0
TIMESTAMP 2026.11.12.18.35.35
"Mouser Part Number" 583-C857
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Rectron/BC857?qs=7pEAo90IqNFxVyLVhJlY7w%3D%3D
"Manufacturer_Name" Rectron
"Manufacturer_Part_Number" BC857
"Description" Bipolar Transistors - BJT SOT23,PNP,0.1A,45V,L owNoise
"Datasheet Link" https://www.arrow.com/en/products/bc857/rectron?region=nac
"Geometry.Height" 1.15mm
GATE 1 3 0
BC857
1 0 U B
2 0 U E
3 0 U C

*END*
*REMARK* SamacSys ECAD Model
1666652/2152596/2.50/3/3/Bridge Rectifier
