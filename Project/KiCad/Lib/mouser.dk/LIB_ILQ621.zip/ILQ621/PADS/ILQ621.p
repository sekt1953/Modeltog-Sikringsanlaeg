*PADS-LIBRARY-PART-TYPES-V9*

ILQ621 DIP762W56P254L1992H470Q16N I ANA 7 1 0 0 0
TIMESTAMP 2026.11.12.18.39.51
"Mouser Part Number" 782-ILQ621
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Semiconductors/ILQ621?qs=xCMk%252BIHWTZMm5K87NCClyQ%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" ILQ621
"Description" Vishay Optocoupler ILQ621 Quad DC Input Transistor Output, 16-Pin PDIP, Through Hole
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-314/312199.pdf
"Geometry.Height" 4.7mm
GATE 1 16 0
ILQ621
1 0 U A_1
2 0 U C_1
3 0 U A_2
4 0 U C_2
5 0 U A_3
6 0 U C_3
7 0 U A_4
8 0 U C_4
16 0 U C_8
15 0 U E_4
14 0 U C_7
13 0 U E_3
12 0 U C_6
11 0 U E_2
10 0 U C_5
9 0 U E_1

*END*
*REMARK* SamacSys ECAD Model
186704/2152596/2.50/16/4/Integrated Circuit
