*PADS-LIBRARY-PART-TYPES-V9*

TBD62083AFWG_EL SOIC127P1032X285-18N I ANA 7 1 0 0 0
TIMESTAMP 2026.11.11.10.05.39
"Mouser Part Number" 757-TBD62083AFWGEL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/TBD62083AFWGEL?qs=fSnNYG2PaKJPpDBB6xK1QA%3D%3D
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" TBD62083AFWG,EL
"Description" Gate Drivers DMOS Transistor Array 8-CH, 50V/0.5A
"Datasheet Link" 
"Geometry.Height" 2.85mm
GATE 1 18 0
TBD62083AFWG_EL
1 0 U I1
2 0 U I2
3 0 U I3
4 0 U I4
5 0 U I5
6 0 U I6
7 0 U I7
8 0 U I8
9 0 U GND
18 0 U O1
17 0 U O2
16 0 U O3
15 0 U O4
14 0 U O5
13 0 U O6
12 0 U O7
11 0 U O8
10 0 U COMMON

*END*
*REMARK* SamacSys ECAD Model
276736/2152596/2.50/18/3/Integrated Circuit
