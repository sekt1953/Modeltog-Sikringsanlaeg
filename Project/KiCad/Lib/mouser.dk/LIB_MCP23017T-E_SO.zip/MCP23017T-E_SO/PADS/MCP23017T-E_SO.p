*PADS-LIBRARY-PART-TYPES-V9*

MCP23017T-E_SO SOIC127P1030X265-28N I ANA 7 1 0 0 0
TIMESTAMP 2026.11.11.10.01.15
"Mouser Part Number" 579-MCP23017T-E/SO
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP23017T-E-SO?qs=usxtMOJb1RylPfT%252BJtgE3Q%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP23017T-E/SO
"Description" Interface - I/O Expanders 16bit Input/Output Exp I2C interface
"Datasheet Link" http://ww1.microchip.com/downloads/en/DeviceDoc/20001952C.pdf
"Geometry.Height" 2.65mm
GATE 1 28 0
MCP23017T-E_SO
1 0 U GPB0
2 0 U GPB1
3 0 U GPB2
4 0 U GPB3
5 0 U GPB4
6 0 U GPB5
7 0 U GPB6
8 0 U GPB7
9 0 U VDD
10 0 U VSS
11 0 U NC_1
12 0 U SCK
13 0 U SDA
14 0 U NC_2
28 0 U GPA7
27 0 U GPA6
26 0 U GPA5
25 0 U GPA4
24 0 U GPA3
23 0 U GPA2
22 0 U GPA1
21 0 U GPA0
20 0 U INTA
19 0 U INTB
18 0 U \RESET
17 0 U A2_2
16 0 U A2_1
15 0 U A0

*END*
*REMARK* SamacSys ECAD Model
239923/2152596/2.50/28/4/Integrated Circuit
